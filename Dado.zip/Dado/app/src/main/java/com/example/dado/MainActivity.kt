package com.example.dado

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/**
 * Esta actividad permite al usuario tirar un dado y ver el resultado en la pantalla.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /* Busca el botón en el diseño */
        val rollButton: Button = findViewById(R.id.button)

        /* Establece un detector de clics en el botón para tirar los dados
        *  cuando el usuario toque el botón */
        rollButton.setOnClickListener() {

            /* Hace un primer lanzamiento de dado al iniciarse la app */
            rodarDado()
        }

    }

    /**
     * Método que tira los dados y actualiza la pantalla con el resultado.
     */
    private fun rodarDado() {

        /* Crea un nuevo objeto Dado con 6 lados y lo lanza */
        val dado = Dado(6)
        val diceRoll = dado.lanzar()

        val imagenDado: ImageView = findViewById(R.id.imageView)

        when (diceRoll) {
            1 -> imagenDado.setImageResource(R.drawable.dado_1)
            2 -> imagenDado.setImageResource(R.drawable.dado_2)
            3 -> imagenDado.setImageResource(R.drawable.dado_3)
            4 -> imagenDado.setImageResource(R.drawable.dado_4)
            5 -> imagenDado.setImageResource(R.drawable.dado_5)
            6 -> imagenDado.setImageResource(R.drawable.dado_6)
        }

        imagenDado.contentDescription = diceRoll.toString()
    }
}

class Dado(private val numeroDeLados: Int) {

    fun lanzar(): Int {
        return (1..numeroDeLados).random()
    }

}